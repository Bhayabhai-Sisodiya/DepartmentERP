import React from 'react';
import './dashboard.css';


const Header = () => {
    return (
        <h1 className='header_title'>Computer Department ERP System</h1>
      );
}
 
export default Header;
