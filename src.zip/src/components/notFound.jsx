import React from "react";

const NotFound = () => {
  return <h1>page not Found</h1>;
};

export default NotFound;
